Contents of Archive:
dataset.csv - This is a data set that you can use to test your neural network.  This IS NOT a full training set or a full test set.  It is meant to serve as an example for you to build upon.  The file contains a list of colors followed by a 1 if the color is blue and 0 if the color is not blue.  You will need to build a larger set of training data to properly train your network.  I suggest googling for color resources (maybe something like "rgb color list").

neuro_example.py - This directory contains example source code (example.py) that demonstrates the use of the neuro package.  Be sure to place the neuro.py and linear_algebra.py files in the same directory as your project source code.  Otherwise, you program will not function!!!
